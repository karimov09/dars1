from django.shortcuts import render, get_object_or_404, redirect
from .models import Destination, Tour, Booking, Customer

def home(request):
    destinations = Destination.objects.all() 
    return render(request, 'index.html', {'destinations': destinations})

def destination_list(request):
    destinations = Destination.objects.all()
    return render(request, 'destination_list.html', {'destinations': destinations})

def tour_list(request, destination_id):
    destination = get_object_or_404(Destination, id=destination_id)
    tours = Tour.objects.filter(destination=destination)
    return render(request, 'tour_list.html', {'destination': destination, 'tours': tours})

def book_tour(request, tour_id):
    tour = get_object_or_404(Tour, id=tour_id)
    customer = get_object_or_404(Customer, id=1)  
    Booking.objects.create(tour=tour, customer=customer)
    return redirect('booking_confirmation')

def customer_profile(request):
    customer = get_object_or_404(Customer, id=1) 
    bookings = Booking.objects.filter(customer=customer) 
    return render(request, 'customer_profile.html', {'customer': customer, 'bookings': bookings})

def booking_confirmation(request):
    return render(request, 'booking_confirmation.html')
