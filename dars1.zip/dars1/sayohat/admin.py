from django.contrib import admin
from .models import Destination, Tour, Booking, Customer

class DestinationAdmin(admin.ModelAdmin):
    list_display = ('name', 'location')

class TourAdmin(admin.ModelAdmin):
    list_display = ('name', 'destination', 'duration', 'price')

class BookingAdmin(admin.ModelAdmin):
    list_display = ('tour', 'customer', 'booking_date')

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'phone')

admin.site.register(Destination, DestinationAdmin)
admin.site.register(Tour, TourAdmin)
admin.site.register(Booking, BookingAdmin)
admin.site.register(Customer, CustomerAdmin)


