from django import template
from sayohat.models import Destination

register = template.Library()

@register.simple_tag
def get_destinations():
    return Destination.objects.all()
