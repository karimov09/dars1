from django.contrib import admin
from django.urls import path
from travel import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'), 
    path('destinations/', views.destinations, name='destinations'),  
    path('tours/', views.tours, name='tours'), 
    path('contact/', views.contact, name='contact'),  
    path('book/<int:tour_id>/', views.book_tour, name='book_tour'), 
]

