
document.addEventListener("DOMContentLoaded", function() {
    console.log("Custom JS loaded successfully!");
});
